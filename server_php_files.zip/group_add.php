<?php
 include "dbcon.php";
 
 $id=$_POST['id'];
 $gname=$_POST['gname']; 	
 $len=$_POST['len'];
 $q=mysqli_query($con,"INSERT INTO group_list (group_name) VALUES ('$gname')");
 $q=mysqli_query($con,"INSERT INTO group_member VALUES (LAST_INSERT_ID(),'$id')");
 for($i=0;$i<$len;$i++) {
	$member=$_POST[$i];
	$q=mysqli_query($con,"INSERT INTO group_member VALUES (LAST_INSERT_ID(),'$member')");
 }
 if($q)
	echo "success"; 
 else
	echo "error"; 
 ?>
