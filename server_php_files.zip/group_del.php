<?php
 include "dbcon.php";
 
 $id=$_POST['id'];
 $gid=$_POST['gid'];
 $q=mysqli_query($con,"delete from group_member where group_id = '$gid' and member = '$id'");
 if($q)
	echo "success"; 
 else
	echo "error"; 
 ?>
