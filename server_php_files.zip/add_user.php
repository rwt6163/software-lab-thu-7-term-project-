<?php
 include "dbcon.php";
 
 $id=$_POST['id'];
 $pw=$_POST['pw'];
 $name=$_POST['name'];
 $q=mysqli_query($con,"insert into user values('$id','$pw','$name')");
 if($q)
	echo "success"; 
 else
	echo "error"; 
 ?>
