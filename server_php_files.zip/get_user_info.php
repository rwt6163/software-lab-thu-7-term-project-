<?php
include "dbcon.php";

$id=$_GET['id'];
$pw=$_GET['pw'];
$error_string = 'error';
$data=array();
$q=mysqli_query($con,"select id, password from user where id = '$id' and password = '$pw'");

while ($row=mysqli_fetch_object($q)){
 $data[]=$row;
}
if(count($data)==0)
	echo json_encode($error_string);
else
	echo json_encode($data);

?>
