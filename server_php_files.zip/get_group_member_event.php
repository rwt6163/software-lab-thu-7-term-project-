<?php
include "dbcon.php";

$gid=$_GET['gid'];

$query = "select event_id, title, start, end, class from group_event where group_id = '$gid'";

$q=mysqli_query($con,$query);

$data=array();

while ($row=mysqli_fetch_object($q)){
	$data[]=$row;
}
echo json_encode($data);
?>
