<?php
include "dbcon.php";

$gid=$_GET['gid'];

$query = "select * from group_event where group_id = '$gid'";

$q=mysqli_query($con,$query);

$data=array();

while ($row=mysqli_fetch_object($q)){
	$row->color = 'yellow';
	$data[]=$row;
}

$query = "select event_id, title, start, end, class, member from personal_event, group_member where group_member.group_id = '$gid' and personal_event.id = group_member.member";
$q=mysqli_query($con,$query);
while ($row=mysqli_fetch_object($q)){
	$row->title = $row->member;
	$row->color = 'red';
	$data[]=$row;
}

echo json_encode($data);
?>
