<?php
 include "dbcon.php";
 
 $id=$_POST['id'];
 $title=$_POST['title'];
 $start=$_POST['start'];
 $end=$_POST['end'];
 
 $query = "INSERT INTO personal_event (title, start, end, id, class) VALUES ";
 $query .= "('$title','$start','$end','$id', 'personal')";
 
 $q=mysqli_query($con,$query);
 
 if($q)
	echo "success"; 
 else
	echo "error"; 

 ?>
