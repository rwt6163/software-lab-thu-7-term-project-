<?php
include "dbcon.php";


$id=$_POST['userid'];

$query="select id from user where id='$id'";
$q=mysqli_query($con,$query);
$row=mysqli_fetch_array($q);

if(!$row)
	echo "success"; 
 else
	echo "error"; 
?>