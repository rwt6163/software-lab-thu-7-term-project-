<?php
include "dbcon.php";

$id=$_GET['id'];

$error_string = 'error';
$data=array();
$q=mysqli_query($con,"select id, name from user where id = '$id'");

while ($row=mysqli_fetch_object($q)){
 $data[]=$row;
}

if(count($data)==0)
	echo json_encode($error_string);
else
	echo json_encode($data);

?>
