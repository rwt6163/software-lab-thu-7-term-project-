<?php
include "dbcon.php";

$id=$_GET['id'];
$query = "select event_id, title, start, end, class from group_event, group_member where group_event.group_id = group_member.group_id and member = '$id'";
$q=mysqli_query($con,$query);

$data=array();

while ($row=mysqli_fetch_object($q)){
	$row->color = 'yellow';
	$row->title = 'group';
	$data[]=$row;
}

$query1 = "select event_id, title, start, end, class from personal_event where id = '$id'";
$q1=mysqli_query($con,$query1);
while ($row=mysqli_fetch_object($q1)){
	$row->color = 'red';
	$data[]=$row;
}

echo json_encode($data);

?>
