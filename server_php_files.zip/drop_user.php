<?php
 include "dbcon.php";
 
 $id=$_POST['id'];
 $q=mysqli_query($con,"delete from user where id = '$id'");
 if($q)
	echo "success"; 
 else
	echo "error"; 
 ?>
