<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","root","0000","android") or die ("could not connect database");
?>