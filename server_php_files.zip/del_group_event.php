<?php
 include "dbcon.php";
 
 $id=$_POST['id'];
 
 $query = "delete from group_event where event_id = '$id'";
 $q=mysqli_query($con,$query);
 
 if($q)
	echo "success"; 
 else
	echo "error"; 

 ?>
