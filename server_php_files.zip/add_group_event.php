<?php
 include "dbcon.php";
 
 $gid=$_POST['gid'];
 $title=$_POST['title'];
 $start=$_POST['start'];
 $end=$_POST['end'];
 
 $query = "INSERT INTO group_event (title, start, end, group_id, class) VALUES ";
 $query .= "('$title','$start','$end','$gid', 'group')";
 
 $q=mysqli_query($con,$query);
 
 if($q)
	echo "success"; 
 else
	echo "error"; 

 ?>
