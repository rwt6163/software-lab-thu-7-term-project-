﻿<?php
include "dbcon.php";

$id=$_GET['id'];

$query = "select id1 from friend where id2 = '$id' and id1 not in (select id2 from friend where id1 = '$id')";
$data=array();
$q=mysqli_query($con,$query);


while ($row=mysqli_fetch_object($q)){
	$data[] = $row;
}

echo json_encode($data);

?>
