<?php
 include "dbcon.php";
 
 $id=$_POST['id'];
 $fid=$_POST['fid'];
 $q=mysqli_query($con,"delete from friend where id1 = '$id' and id2 = '$fid'");
 $p=mysqli_query($con,"delete from friend where id1 = '$fid' and id2 = '$id'");
 if($q && $p)
	echo "success"; 
 else
	echo "error"; 
 ?>
