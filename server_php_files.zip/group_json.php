<?php
include "dbcon.php";

$id=$_GET['id'];

$query = "create view tmp as ";
$query .= "select g1.group_id, g1.group_name, g2.member from group_list as ";
$query .= "g1, group_member as g2 where g1.group_id = g2.group_id";
$q=mysqli_query($con,$query);

$query2 = "select t.group_id, t.group_name, t.member from tmp as t, group_member as g where ";
$query2 .= "g.member = '$id' and g.group_id = t.group_id";

$q2=mysqli_query($con,$query2);

$data=array();

while ($row=mysqli_fetch_object($q2)){
	$data[]=$row;
}
echo json_encode($data);

$query3 = "drop view tmp";
$q3=mysqli_query($con,$query3);
?>
