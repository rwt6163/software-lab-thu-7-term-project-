<?php
include "dbcon.php";

$id=$_GET['id'];
$query = "create view tmp as ";
$query .= "select g1.group_id, g1.group_name, g2.member from group_list as ";
$query .= "g1, group_member as g2 where g1.group_id = g2.group_id";
$q=mysqli_query($con,$query);

$data=array();
$q=mysqli_query($con,"select * from tmp where member = '$id'");

while ($row=mysqli_fetch_object($q)){
	$data[]=$row;
}

$query2 = "drop view tmp";
mysqli_query($con,$query2);

echo json_encode($data);

?>
