<?php
 include "dbcon.php";
 
 $id=$_POST['id'];
 $fid=$_POST['fid'];
 
 $q=mysqli_query($con,"INSERT INTO friend VALUES ('$id', '$fid')");
 
 if($q)
	echo "success"; 
 else
	echo "error"; 
 ?>
